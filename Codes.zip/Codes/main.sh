#!/bin/bash
#SBATCH --job-name=main
#SBATCH --account=ACF-UTHSC0001
#SBATCH --partition=campus
#SBATCH --qos=campus
#SBATCH --output=main.o%j
#SBATCH --error=main.e%j
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --time=01-00:00:00

###########################################
cd $SLURM_SUBMIT_DIR
echo "Current directory: $(pwd)"
###########################################
eval "$(conda shell.bash hook)"

source activate multiethnic

echo "The environment has been activated."

python main.py BLCA Methylation DFI 2 ASIAN

echo "The execution has been done."



