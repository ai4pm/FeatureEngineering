# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 10:01:47 2023

@author: Teena Sharma
"""

import argparse
from numpy.random import seed
import pandas as pd
import random as rn
import os
import pickle
import numpy as np
from sklearn.decomposition import PCA
import time
from sklearn.preprocessing import MinMaxScaler
import keras
from keras import layers
from keras.models import model_from_json
from preProcess import tumor_types, run_cv_gender_race_comb, \
        get_protein, get_mRNA, get_MicroRNA, get_Methylation, \
        standarize_dataset, get_n_years, get_independent_data_single
from classify_all import run_mixture_cv, run_one_race_cv, \
        run_unsupervised_transfer_cv, run_CCSA_transfer, \
        run_supervised_transfer_cv, run_naive_transfer_cv, \
        FADA_classification 
from tensorflow import set_random_seed

seed(11111)
set_random_seed(11111)
os.environ['PYTHONHASHSEED'] = '0'
os.environ["KERAS_BACKEND"] = "tensorflow"
rn.seed(11111)

folderISAAC = 'Autoencoder/'
if os.path.exists(folderISAAC)!=True:
    folderISAAC = './'

EncoderActivation = 'linear' # 'relu'
DecoderActivation = 'linear'
LossFunction = 'mean_squared_error' # 'binary_crossentropy'
AE = True # Set this True if want to use AE for feature extraction else False
AE_MLTask = 4 # this setting sets the condition where AE is trained using All samples for each omics feature
PCA_FE_All = False # Set this True if want to use PCA for dimensionality reduction else False

def main():
    
    parser = argparse.ArgumentParser()
    parser.add_argument("cancer_type", type=str, help="Cancer Type")
    parser.add_argument("feature_type", type=str, help="Feature Type")
    parser.add_argument("target", type=str, help="Clinical Outcome Endpoint")
    parser.add_argument("years", type=int, help="Event Time Threhold (Years)")
    parser.add_argument("target_domain", type=str, help="Target Group")
    
    args = parser.parse_args()
    print(args)
    
    cancer_type = args.cancer_type
    feature_type = args.feature_type
    target = args.target
    years = args.years
    target_domain = args.target_domain
    
    # set this False if want to apply feature selection/ dimensionality reduction
    OriginalFeatures = False
    # OriginalFeatures = True if args.OriginalFeatures_val==1 else False
    if OriginalFeatures:
        print('=====================================================================')
        print('Original features to be used for machine learning, no feature selection/dimensionality reduction will be applied')
        print('=====================================================================')
        features_count = -1
    else: # feature extraction, dimensionality reduction, feature selection
        print('=====================================================================')
        print('Feature selection/dimensionality reduction will be applied')
        print('=====================================================================')
        if AE:
            print('=====================================================================')
            print('Autoencoder will be used for feature extraction')
            print('=====================================================================')
        elif PCA_FE_All:
            print('=====================================================================')
            print('PCA will be used for feature extraction with All samples')
            print('=====================================================================')
        else:
            print('=====================================================================')
            print('ANOVA based Feature selection will be applied')
            print('=====================================================================')
        # No. of features to be selected/extracted
        features_count = 200
    
    if AE:
        AE_batchsize = 20
        AE_iter = 100
    source_domain = 'WHITE'
    genders = ("MALE","FEMALE")
    groups = (source_domain,target_domain)
    data_Category = 'R' # 'R', 'GR' ; it is 'GR' if MGtoMGF (Or) MGtoMGM = True
    MGtoMGF = True if data_Category=='GR' else False
    MGtoMGM = True if data_Category=='GR' else False
    
    TaskName = 'TCGA-'+cancer_type+'-'+str(feature_type)+'-'+ groups[0]+'-'+groups[1]+'-'+target+'-'+str(years)+'YR'
    out_file_name = folderISAAC + 'Result/' + TaskName + '.xlsx'
    CCSA_path = folderISAAC +'CCSA_data/' + TaskName + '/CCSA_pairs'
    checkpt_path = folderISAAC+'ckpt/FADA_'+TaskName+'_checkpoint.pt'
    if OriginalFeatures:
        out_file_name = folderISAAC + 'Result/' + TaskName + '_OriginalFeatures.xlsx'
    if AE:
        out_file_name = folderISAAC + 'Result/' + TaskName + '_AE_Category'+str(AE_MLTask)+'.xlsx'
    if PCA_FE_All:
        out_file_name = folderISAAC + 'Result/' + TaskName + '_PCA_FE_All.xlsx'
    print("===============================================")
    print(out_file_name)
    print("===============================================")
    
    if os.path.exists(out_file_name)==True: # if result already exist
        print('===================================')
        print('Result file already exists.')
        print('===================================')
    else:
        if len(np.shape(feature_type))==0:
            print('===============')
            print('Single Omics')
            print('===============')
        else:
            print('===============')
            print('Multi Omics')
            print('===============')
            if len(feature_type)==2: # multi omics with 2 features
                feat_1 = feature_type[0]
                feat_2 = feature_type[1]
                if feat_1=='Protein':
                    f_num = 189
                elif feat_1=='mRNA':
                    f_num = 17176
                elif feat_1=='MicroRNA':
                    f_num = 662
                elif feat_1=='Methylation':
                    f_num = 11882
        
        if AE:
            # names of AEs
            if len(np.shape(feature_type))==0: # single omics
                AE_ModelName = 'TCGA-' + feature_type
            else: # multi omics
                if len(feature_type)==2: # multi omics with 2 features
                    AE_ModelName_1 = 'TCGA-' + feat_1
                    AE_ModelName_2 = 'TCGA-' + feat_2
            # All samples for single AE
            if AE_MLTask==4:
                if len(np.shape(feature_type))==0: # single omics
                    AE_ModelName = 'TCGA-' + feature_type
                else: # multi omics
                    if len(feature_type)==2: # multi omics with 2 features
                        AE_ModelName_1 = 'TCGA-' + feat_1
                        AE_ModelName_2 = 'TCGA-' + feat_2
            # Path and file names of AE as per the value of AE_MLTask
            if len(np.shape(feature_type))==0: # single omics
                # Autoencoder for all samples
                AE_json_file_name = folderISAAC+'AE_models/autoencoder_'+AE_ModelName+'.json'
                E_json_file_name = folderISAAC+'AE_models/encoder_'+AE_ModelName+'.json'
            else: # multi omics
                if len(feature_type)==2: # multi omics with 2 features
                    # Autoencoder for all samples
                    AE_json_file_name_1 = folderISAAC+'AE_models/autoencoder_'+AE_ModelName_1+'.json'
                    AE_json_file_name_2 = folderISAAC+'AE_models/autoencoder_'+AE_ModelName_2+'.json'
                    E_json_file_name_1 = folderISAAC+'AE_models/encoder_'+AE_ModelName_1+'.json'
                    E_json_file_name_2 = folderISAAC+'AE_models/encoder_'+AE_ModelName_2+'.json'
            # Training AE
            AE_train = False
            while(AE_train==False):
                if len(np.shape(feature_type))==0: # single omics
                    Condition_AE = os.path.exists(AE_json_file_name) and os.path.exists(E_json_file_name)
                else: # multi omics
                    if len(feature_type)==2: # multi omics with 2 features
                        Condition_AE = (os.path.exists(AE_json_file_name_1) and os.path.exists(AE_json_file_name_2) \
                                    and os.path.exists(E_json_file_name_1) and os.path.exists(E_json_file_name_2))
                if Condition_AE==1:
                    # No AE training needed
                    AE_train = False
                    print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                    print('AE training is not needed.')
                    print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                    if len(np.shape(feature_type))==0: # single omics
                        print('Reading saved AE model.')
                        json_file = open(E_json_file_name, 'r')
                        loaded_model_json = json_file.read()
                        json_file.close()
                        encoder = model_from_json(loaded_model_json)
                    else: # multi omics
                        if len(feature_type)==2: # multi omics with 2 features
                            print('Reading saved AE models.')
                            #################################################################
                            #################################################################
                            #################################################################
                            ### I will write this part of code later ########################
                            #################################################################
                            #################################################################
                            #################################################################
                    break
                else:
                    # AE training is needed
                    AE_train = True
                    print('$$$$$$$$$$$$$$$$$$$$$$')
                    print('AE training is needed.')
                    print('$$$$$$$$$$$$$$$$$$$$$$')
                    if len(np.shape(feature_type))==0: # single omics
                        if feature_type=='mRNA':
                            dataset = get_mRNA(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                                AE_MLTask=AE_MLTask, PCA_FE_All=PCA_FE_All)
                        elif feature_type=='MicroRNA':
                            dataset = get_MicroRNA(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                                AE_MLTask=AE_MLTask, PCA_FE_All=PCA_FE_All)
                        elif feature_type=='Protein':
                            dataset = get_protein(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                                AE_MLTask=AE_MLTask, PCA_FE_All=PCA_FE_All)
                        elif feature_type=='Methylation':
                            dataset = get_Methylation(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                                AE_MLTask=AE_MLTask, PCA_FE_All=PCA_FE_All)
                    else: # multi omics
                        dataset = run_cv_gender_race_comb(cancer_type=cancer_type,feature_type=feature_type,target=target,genders=genders,groups=groups,data_Category=data_Category,
                                                AE_MLTask=AE_MLTask, PCA_FE_All=PCA_FE_All)
                    dataset = standarize_dataset(dataset)
                    X = dataset['X']
                    
                    encoding_dim = features_count
                    if len(np.shape(feature_type))==0: # single omics
                        print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                        print('Train AE for '+str(features_count)+' features')
                        print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                        ######### Training AE with all samples #########
                        standard_scaler = MinMaxScaler()
                        X_AE = pd.DataFrame(standard_scaler.fit_transform(X))
                        encoded_input = keras.Input(shape=(X_AE.shape[1],))
                        encoded = layers.Dense(encoding_dim, activation=EncoderActivation, name='encoder')(encoded_input)
                        decoded = layers.Dense(np.shape(X_AE)[1], activation=DecoderActivation)(encoded)
                        autoencoder = keras.Model(encoded_input, decoded)
                        autoencoder.compile(optimizer='adam', loss=LossFunction)
                        history_AE = autoencoder.fit(X_AE, X_AE,epochs=AE_iter,batch_size=AE_batchsize,shuffle=True)
                        encoder = keras.Model(encoded_input,encoded)
                        json_model = autoencoder.to_json()
                        json_file = open(AE_json_file_name, 'w')
                        json_file.write(json_model)
                        json_file.close()
                        json_model = encoder.to_json()
                        json_file = open(E_json_file_name, 'w')
                        json_file.write(json_model)
                        json_file.close()
                    else: # multi omics
                        if len(feature_type)==2: # multi omics with 2 features
                            print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                            print('Train two different AEs for '+str(features_count//2)+'+'+str(features_count//2)+' features for the combination of two features')
                            print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                            X_1 = X[:,0:f_num]
                            X_2 = X[:,f_num:]
                            #################################################################
                            #################################################################
                            #################################################################
                            ### I will write this part of code later ########################
                            #################################################################
                            #################################################################
                            #################################################################
                            print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                            print('Two different AE models have been trained and saved.')
                            print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                    AE_train = False
        
        # Reading data for input machine learning task
        if len(np.shape(feature_type))==0: # single omics
            if feature_type=='mRNA':
                dataset = get_mRNA(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                    AE_MLTask=None, PCA_FE_All=PCA_FE_All)
            elif feature_type=='MicroRNA':
                dataset = get_MicroRNA(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                    AE_MLTask=None, PCA_FE_All=PCA_FE_All)
            elif feature_type=='Protein':
                dataset = get_protein(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                    AE_MLTask=None, PCA_FE_All=PCA_FE_All)
            elif feature_type=='Methylation':
                dataset = get_Methylation(cancer_type=cancer_type,target=target,groups=groups,Gender=genders,data_Category=data_Category,
                                    AE_MLTask=None, PCA_FE_All=PCA_FE_All)
        else: # multi omics
            dataset = run_cv_gender_race_comb(cancer_type=cancer_type,feature_type=feature_type,target=target,genders=genders,groups=groups,data_Category=data_Category,
                                    AE_MLTask=None, PCA_FE_All=PCA_FE_All)
        k = features_count if (features_count<=(np.shape(dataset['X'])[1])) else -1
        dataset = standarize_dataset(dataset)
        
        if AE: # extracting features for input machine learning task
            if ((AE_MLTask==0) or (AE_MLTask==1) or (AE_MLTask==2) or (AE_MLTask==3) or (AE_MLTask==4)):
                X = dataset['X']
                if len(np.shape(feature_type))==0: # single omics
                    standard_scaler = MinMaxScaler()
                    X_AE = pd.DataFrame(standard_scaler.fit_transform(X))
                    reduced_df_X_AE = pd.DataFrame(encoder.predict(np.array(X_AE)))
                    X_AE = np.array(reduced_df_X_AE)
                else: # multi omics
                    if len(feature_type)==2: # multi omics with 2 features
                        standard_scaler_1 = MinMaxScaler()
                        standard_scaler_2 = MinMaxScaler()
                        #################################################################
                        #################################################################
                        #################################################################
                        ### I will write this part of code later ########################
                        #################################################################
                        #################################################################
                        #################################################################
                k = -1
                dataset['X'] = X_AE
        
        if PCA_FE_All:
            
            datasetName = folderISAAC + 'PCA_data/dataset_' + feature_type + '_' + target + '_' + target_domain +'.pickle'
            
            if os.path.exists(datasetName)==True:
                print('###########################')
                print('Dataset for PCA already available.')
                print('###########################')
                with open(datasetName, 'rb') as file:
                    dataset = pickle.load(file)
            else:
                X = dataset['X']
                if len(np.shape(feature_type))==0: # single omics
                    standard_scaler = MinMaxScaler()
                    X_PCA = pd.DataFrame(standard_scaler.fit_transform(X))
                    pca = PCA(n_components=features_count)
                    X_PCA = pca.fit_transform(X_PCA)
                else: # multi omics
                    if len(feature_type)==2: # multi omics with 2 features
                        standard_scaler_1 = MinMaxScaler()
                        standard_scaler_2 = MinMaxScaler()
                        #################################################################
                        #################################################################
                        #################################################################
                        ### I will write this part of code later ########################
                        #################################################################
                        #################################################################
                        #################################################################
                k = -1
                dataset['X'] = X_PCA
                
                tumorAll = pd.DataFrame(dataset['TumorType'])
                tumor_inp = tumor_types(cancer_type)
                tumorin = tumorAll[tumorAll[0].isin(tumor_inp)]
                selected_row_numbers = tumorin.index
                # C
                C_new = pd.DataFrame(dataset['C'])
                C_new = C_new[0][selected_row_numbers.values]
                E_new = [1 - c for c in C_new]
                C_new = C_new.tolist()
                C_new = np.asarray(C_new, dtype=np.int32)
                #E_new = E_new.tolist()
                E_new = np.asarray(E_new, dtype=np.int32)
                # G
                G_new = pd.DataFrame(dataset['G'])
                G_new = G_new[0][selected_row_numbers.values]
                G_new = G_new.tolist()
                G_new = np.asarray(G_new)
                # R
                R_new = pd.DataFrame(dataset['R'])
                R_new = R_new[0][selected_row_numbers.values]
                R_new = R_new.tolist()
                R_new = np.asarray(R_new)
                # T
                T_new = pd.DataFrame(dataset['T'])
                T_new = T_new[0][selected_row_numbers.values]
                T_new = T_new.tolist()
                T_new = np.asarray(T_new, dtype=np.float32)
                # X
                X_new = pd.DataFrame(dataset['X'])
                X_new = X_new.iloc[selected_row_numbers.values,:]
                X_new = X_new.values
                X_new = X_new.astype('float32')
                
                dataset['C'] = C_new
                dataset['E'] = E_new
                dataset['G'] = G_new
                dataset['R'] = R_new
                dataset['T'] = T_new
                dataset['X'] = X_new
                
                with open(datasetName, 'wb') as file:
                    pickle.dump(dataset, file)
        
        ## Independent Learning datasets ##
        # Independent - WHITE
        data_w = get_independent_data_single(dataset, 'WHITE', groups, genders)
        data_w = get_n_years(data_w, years)
        # Independent - MG
        data_b = get_independent_data_single(dataset, 'MG', groups, genders)
        data_b = get_n_years(data_b, years)
        if data_Category=='GR':
            # Independent - WHITE-FEMALE
            data_wf = get_independent_data_single(dataset, 'WHITE-FEMALE', groups, genders)
            data_wf = get_n_years(data_wf, years)
            # Independent - WHITE-MALE
            data_wm = get_independent_data_single(dataset, 'WHITE-MALE', groups, genders)
            data_wm = get_n_years(data_wm, years)
            # Independent - BLACK-FEMALE
            data_bf = get_independent_data_single(dataset, 'BLACK-FEMALE', groups, genders)
            data_bf = get_n_years(data_bf, years)
            # Independent - BLACK-MALE
            data_bm = get_independent_data_single(dataset, 'BLACK-MALE', groups, genders)
            data_bm = get_n_years(data_bm, years)
        ## Mixture, Naive Transfer, and Transfer Learning dataset ##
        dataset_tl = dataset
        dataset_tl = get_n_years(dataset_tl, years)
        #dataset_tl_ccsa = normalize_dataset(dataset)
        #dataset_tl_ccsa = get_n_years(dataset_tl_ccsa, years)
        dataset = get_n_years(dataset, years)
        
        print (cancer_type, feature_type, target, years, source_domain, target_domain)
        X, Y, R, y_sub, y_strat, G, Gy_strat, GRy_strat = dataset
        df = pd.DataFrame(y_strat, columns=['RY'])
        df['GRY'] = GRy_strat
        df['GY'] = Gy_strat
        df['R'] = R
        df['G'] = G
        df['Y'] = Y
        print(X.shape)
        print(df['GRY'].value_counts())#gender with prognosis counts
        print(df['GY'].value_counts())#gender with prognosis counts
        print(df['G'].value_counts())#gender counts
        print(df['RY'].value_counts())#race with prognosis counts
        print(df['R'].value_counts())#race counts
        print(df['Y'].value_counts())#progonsis counts
        
        ###############################
        # parameters #
        ###############################
        parametrs_mix = {'fold': 3, 'k': k, 'val_size':0.0, 'batch_size':20,'momentum':0.9, 'learning_rate':0.01,
                        'lr_decay':0.03, 'dropout':0.5, 'L1_reg': 0.001,'L2_reg': 0.001, 'hiddenLayers': [128,64]}
        parameters_MAJ = {'fold':3, 'k':k, 'batch_size':20, 'lr_decay':0.03, 'val_size':0.0, 'learning_rate':0.01,
                        'dropout':0.5, 'L1_reg':0.001, 'L2_reg':0.001, 'hiddenLayers':[128,64]}
        parameters_MIN = {'fold':3, 'k':k, 'batch_size':4, 'lr_decay':0.03, 'val_size':0.0, 'learning_rate':0.01,
                        'dropout':0.5, 'L1_reg':0.001, 'L2_reg':0.001, 'hiddenLayers':[128,64]}
        parameters_NT  = {'fold':3, 'k':k, 'batch_size':20, 'momentum':0.9, 'lr_decay':0.03, 'val_size':0.0,
                        'learning_rate':0.01, 'dropout':0.5, 'L1_reg':0.001, 'L2_reg':0.001, 'hiddenLayers':[128,64]}
        parameters_TL1 = {'fold':3, 'k':k, 'batch_size':20, 'momentum':0.9, 'lr_decay':0.03, 'val_size':0.0,
                        'learning_rate':0.01, 'dropout':0.5, 'L1_reg':0.001, 'L2_reg':0.001, 'hiddenLayers':[128,64],
                        'train_epoch':100, 'tune_epoch':100, 'tune_lr':0.002, 'tune_batch':10}
        parameters_TL2 = {'fold':3, 'k':k, 'batch_size':10, 'lr_decay':0.03, 'val_size':0.0, 'learning_rate':0.002,
                        'n_epochs':100, 'dropout':0.5, 'L1_reg':0.001, 'L2_reg':0.001, 'hiddenLayers':[128,64]}
        parameters_TL3 = {'fold':3, 'n_features':k, 'alpha':0.3, 'batch_size':20, 'learning_rate':0.01, 'hiddenLayers':[100],
                        'dr':0.5, 'momentum':0.9, 'decay':0.03, 'sample_per_class':2, 'SourcePairs':False}
        parameters_TL4 = {'fold':3, 'n_features':k, 'alpha':0.25, 'batch_size':20, 'learning_rate':0.01, 'hiddenLayers':[128,64],
                        'dr':0.5, 'momentum':0.9, 'decay':0.03, 'sample_per_class':2, 'EarlyStop':False,
                        'L1_reg':0.001, 'L2_reg':0.001, 'patience':100, 'n_epochs':100}
        
        res = pd.DataFrame()
        for i in range(20):
            print('###########################')
            print('Interation no.: '+str(i+1))
            print('###########################')
            seed = i
            start_iter = time.time()
            df_mix = run_mixture_cv(seed, dataset, groups, genders, data_Category, MGtoMGF, MGtoMGM, feature_type, False, **parametrs_mix)
            print('###########################')
            print('Mixture is done')
            print('###########################')
            df_w = run_one_race_cv(seed, data_w, feature_type, False, **parameters_MAJ)
            df_w = df_w.rename(columns={"Auc": "W_ind"})
            print('###########################')
            print('Independent EA is done.')
            print('###########################')
            df_b = run_one_race_cv(seed, data_b, feature_type, False, **parameters_MIN)
            df_b = df_b.rename(columns={"Auc": "B_ind"})
            print('###########################')
            print('Independent MG is done.')
            print('###########################')
            if data_Category=='GR':
                if MGtoMGF:
                    df_wf = run_one_race_cv(seed, data_wf, feature_type, False, **parameters_MAJ)
                    df_wf = df_wf.rename(columns={"Auc": "WF_ind"})
                    print('Independent EA(F) is done.')
                    df_bf = run_one_race_cv(seed, data_bf, feature_type, False, **parameters_MIN)
                    df_bf = df_bf.rename(columns={"Auc": "BF_ind"})
                    print('Independent MG(F) is done.')
                if MGtoMGM:
                    df_wm = run_one_race_cv(seed, data_wm, feature_type, False, **parameters_MAJ)
                    df_wm = df_wm.rename(columns={"Auc": "WM_ind"})
                    print('Independent EA(M) is done.')
                    df_bm = run_one_race_cv(seed, data_bm, feature_type, False, **parameters_MIN)
                    df_bm = df_bm.rename(columns={"Auc": "BM_ind"})
                    print('Independent MG(M) is done.')
                print('###########################')
                print('Independent for Gender Racial Compositions is done.')
                print('###########################')
            df_nt = run_naive_transfer_cv(seed, 'WHITE', 'MG', dataset, groups, genders, feature_type, False, **parameters_NT)
            df_nt = df_nt.rename(columns={"NT_Auc": "NT_Auc"})
            if MGtoMGF: 
                df_nt_f = run_naive_transfer_cv(seed, 'WHITE', 'MG-FEMALE', dataset, groups, genders, feature_type, False, **parameters_NT)
                df_nt_f = df_nt_f.rename(columns={"NT_Auc": "NT_Auc_MGF"})
                print('Naive Transfer is done for MG-FEMALE.')
            if MGtoMGM: 
                df_nt_m = run_naive_transfer_cv(seed, 'WHITE', 'MG-MALE', dataset, groups, genders, feature_type, False, **parameters_NT)
                df_nt_m = df_nt_m.rename(columns={"NT_Auc": "NT_Auc_MGM"})
                print('Naive Transfer is done for MG-MALE.')
            print('###########################')
            print('Naive Transfer is done.')
            print('###########################')
            if data_Category=='GR':
                df_tl_sup_EAF = run_supervised_transfer_cv(seed, 'WHITE-FEMALE', 'MG-FEMALE', dataset, groups, genders, False, False, feature_type, False, **parameters_TL1)
                df_tl_sup_EAF = df_tl_sup_EAF.rename(columns={"TL_Auc": "TL_sup_EAF_MGF"})
                print('Supervised is done for EA(F).')
                df_tl_sup_EAM = run_supervised_transfer_cv(seed, 'WHITE-MALE', 'MG-MALE', dataset, groups, genders, False, False, feature_type, False, **parameters_TL1)
                df_tl_sup_EAM = df_tl_sup_EAM.rename(columns={"TL_Auc": "TL_sup_EAM_MGM"})
                print('Supervised is done for EA(M).')
                df_tl_sup_EA_EAF = run_supervised_transfer_cv(seed, 'WHITE', 'MG-FEMALE', dataset, groups, genders, False, False, feature_type, False, **parameters_TL1)
                df_tl_sup_EA_EAF = df_tl_sup_EA_EAF.rename(columns={"TL_Auc": "TL_sup_EA_MGF"})
                print('Supervised is done for EA--MG(F).')
            df_tl_sup = run_supervised_transfer_cv(seed, 'WHITE', 'MG', dataset_tl, groups, genders, MGtoMGF, MGtoMGM, feature_type, False, **parameters_TL1)
            if data_Category=='GR':
                if MGtoMGF and MGtoMGM:
                    df_tl_sup = df_tl_sup.rename(columns={"TL_Auc": "TL_sup","TL_Auc_MGF": "TL_sup_MGF","TL_Auc_MGM": "TL_sup_MGM"})
                if MGtoMGF:
                    df_tl_sup = df_tl_sup.rename(columns={"TL_Auc": "TL_sup","TL_Auc_MGF": "TL_sup_MGF"})
                if MGtoMGM:
                    df_tl_sup = df_tl_sup.rename(columns={"TL_Auc": "TL_sup","TL_Auc_MGM": "TL_sup_MGM"})
            elif data_Category=='R':
                df_tl_sup = df_tl_sup.rename(columns={"TL_Auc": "TL_sup"})
            print('###########################')
            print('Supervised is done.')
            print('###########################')
            if data_Category=='GR':
                df_tl_unsup_EAM = run_unsupervised_transfer_cv(seed, 'WHITE-MALE', 'MG-MALE', dataset, groups, genders, False, False, feature_type, False, **parameters_TL2)
                df_tl_unsup_EAM = df_tl_unsup_EAM.rename(columns={"TL_Auc": "TL_unsup_EAM_MGM"})
                print('Unsupervised is done for EA(M).')
                df_tl_unsup_EAF = run_unsupervised_transfer_cv(seed, 'WHITE-FEMALE', 'MG-FEMALE', dataset, groups, genders, False, False, feature_type, False, **parameters_TL2)
                df_tl_unsup_EAF = df_tl_unsup_EAF.rename(columns={"TL_Auc": "TL_unsup_EAF_MGF"})
                print('Unsupervised is done for EA(F).')
                df_tl_unsup_EA_EAF = run_unsupervised_transfer_cv(seed, 'WHITE', 'MG-FEMALE', dataset, groups, genders, False, False, 
                                                                feature_type, **parameters_TL2)
                df_tl_unsup_EA_EAF = df_tl_unsup_EA_EAF.rename(columns={"TL_Auc": "TL_unsup_EA_MGF"})
                print('Unsupervised is done for EA--MG(F).')
            df_tl_unsup = run_unsupervised_transfer_cv(seed, 'WHITE', 'MG', dataset_tl, groups, genders, MGtoMGF, MGtoMGM, feature_type, False, **parameters_TL2)
            if data_Category=='GR':
                if MGtoMGF and MGtoMGM:
                    df_tl_unsup = df_tl_unsup.rename(columns={"TL_Auc": "TL_unsup","TL_Auc_MGF": "TL_unsup_MGF","TL_Auc_MGM": "TL_unsup_MGM"})
                if MGtoMGF:
                    df_tl_unsup = df_tl_unsup.rename(columns={"TL_Auc": "TL_unsup","TL_Auc_MGF": "TL_unsup_MGF"})
                if MGtoMGM:
                    df_tl_unsup = df_tl_unsup.rename(columns={"TL_Auc": "TL_unsup","TL_Auc_MGM": "TL_unsup_MGM"})
            elif data_Category=='R':
                df_tl_unsup = df_tl_unsup.rename(columns={"TL_Auc": "TL_unsup"})
            print('###########################')
            print('Unsupervised is done.')
            print('###########################')
            if data_Category=='GR':
                df_tl_ccsa_EAM = run_CCSA_transfer(seed, 'WHITE-MALE', 'MG-MALE', dataset, groups, genders, False, False, CCSA_path,feature_type, False, **parameters_TL3)
                df_tl_ccsa_EAM = df_tl_ccsa_EAM.rename(columns={"TL_Auc": "TL_ccsa_EAM_MGM"})
                print('CCSA is done for EA(M).')
                df_tl_ccsa_EAF = run_CCSA_transfer(seed, 'WHITE-FEMALE', 'MG-FEMALE', dataset, groups, genders, False, False, CCSA_path, feature_type, False, **parameters_TL3)
                df_tl_ccsa_EAF = df_tl_ccsa_EAF.rename(columns={"TL_Auc": "TL_ccsa_EAF_MGF"})
                print('CCSA is done for EA(F).')
                df_tl_ccsa_EA_EAF = run_CCSA_transfer(seed, 'WHITE', 'MG-FEMALE', dataset, groups, genders, False, False, CCSA_path, feature_type, False, **parameters_TL3)
                df_tl_ccsa_EA_EAF = df_tl_ccsa_EA_EAF.rename(columns={"TL_Auc": "TL_ccsa_EA_MGF"})
                print('CCSA is done for EA--MG(F).')
            df_tl_ccsa = run_CCSA_transfer(seed, 'WHITE', 'MG', dataset_tl, groups, genders, MGtoMGF, MGtoMGM, CCSA_path, feature_type, False, **parameters_TL3)
            if data_Category=='GR':
                if MGtoMGF and MGtoMGM:
                    df_tl_ccsa = df_tl_ccsa.rename(columns={"TL_Auc": "TL_ccsa", "TL_Auc_MGF": "TL_ccsa_MGF", "TL_Auc_MGM": "TL_ccsa_MGM"})
                if MGtoMGF:
                    df_tl_ccsa = df_tl_ccsa.rename(columns={"TL_Auc": "TL_ccsa", "TL_Auc_MGF": "TL_ccsa_MGF"})
                if MGtoMGM:
                    df_tl_ccsa = df_tl_ccsa.rename(columns={"TL_Auc": "TL_ccsa", "TL_Auc_MGM": "TL_ccsa_MGM"})
            elif data_Category=='R':
                df_tl_ccsa = df_tl_ccsa.rename(columns={"TL_Auc": "TL_ccsa"})
            print('###########################')
            print('CCSA is done.')
            print('###########################')
            if data_Category=='GR':
                df_tl_fada_EAM = FADA_classification(seed, 'WHITE-MALE', 'MG-MALE', dataset, groups, genders, False, False, checkpt_path, feature_type, False, **parameters_TL4)
                df_tl_fada_EAM = df_tl_fada_EAM.rename(columns={"TL_DCD_Auc":"TL_FADA_EAM_MGM"})
                print('FADA is done for EA(M).')
                df_tl_fada_EAF = FADA_classification(seed, 'WHITE-FEMALE', 'MG-FEMALE', dataset, groups, genders, False, False, checkpt_path, feature_type, False, **parameters_TL4)
                df_tl_fada_EAF = df_tl_fada_EAF.rename(columns={"TL_DCD_Auc":"TL_FADA_EAF_MGF"})
                print('FADA is done for EA(F).')
                df_tl_fada_EA_EAF = FADA_classification(seed, 'WHITE', 'MG-FEMALE', dataset, groups, genders, False, False, checkpt_path, feature_type, False, **parameters_TL4)
                df_tl_fada_EA_EAF = df_tl_fada_EA_EAF.rename(columns={"TL_DCD_Auc": "TL_FADA_EA_MGF"})
                print('FADA is done for EA--MG(F).')
            df_tl_fada = FADA_classification(seed, 'WHITE', 'MG', dataset_tl, groups, genders, MGtoMGF, MGtoMGM, checkpt_path, feature_type, False, **parameters_TL4)
            if data_Category=='GR':
                if MGtoMGF and MGtoMGM:
                    df_tl_fada = df_tl_fada.rename(columns={"TL_DCD_Auc":"TL_FADA", "TL_Auc_MGF":"TL_FADA_MGF", "TL_Auc_MGM":"TL_FADA_MGM"})
                if MGtoMGF:
                    df_tl_fada = df_tl_fada.rename(columns={"TL_DCD_Auc":"TL_FADA", "TL_Auc_MGF":"TL_FADA_MGF"})
                if MGtoMGM:
                    df_tl_fada = df_tl_fada.rename(columns={"TL_DCD_Auc":"TL_FADA", "TL_Auc_MGM":"TL_FADA_MGM"})
            elif data_Category=='R':
                df_tl_fada = df_tl_fada.rename(columns={"TL_DCD_Auc":"TL_FADA"})
            print('###########################')
            print('FADA is done.')
            print('###########################')
            end_iter = time.time()
            print("The time of loop execution is :", end_iter-start_iter)
            timeFor_iter = pd.DataFrame({'Time':[end_iter - start_iter]},index=[seed])
            if data_Category=='R':
                df1 = pd.concat([timeFor_iter,
                                    df_mix,
                                    df_w, df_b, 
                                    df_nt,
                                    df_tl_sup, 
                                    df_tl_unsup,
                                    df_tl_ccsa, 
                                    df_tl_fada
                                    ], sort=False, axis=1)
            elif data_Category=='GR':
                if MGtoMGF:
                    df1 = pd.concat([timeFor_iter, 
                                    df_mix,
                                    df_w, df_b, df_wf, df_bf, 
                                    df_nt, df_nt_f,
                                    df_tl_sup, df_tl_sup_EAF, df_tl_sup_EAM, df_tl_sup_EA_EAF,
                                    df_tl_unsup, df_tl_unsup_EAF, df_tl_unsup_EAM, df_tl_unsup_EA_EAF,
                                    df_tl_ccsa, df_tl_ccsa_EAF, df_tl_ccsa_EAM, df_tl_ccsa_EA_EAF,
                                    df_tl_fada, df_tl_fada_EAF, df_tl_fada_EAM, df_tl_fada_EA_EAF
                                    ], sort=False, axis=1)
                if MGtoMGM:
                    df1 = pd.concat([timeFor_iter, 
                                    df_mix,
                                    df_w, df_b, df_wm, df_bm, 
                                    df_nt, df_nt_m,
                                    df_tl_sup, df_tl_sup_EAF, df_tl_sup_EAM, df_tl_sup_EA_EAF,
                                    df_tl_unsup, df_tl_unsup_EAF, df_tl_unsup_EAM, df_tl_unsup_EA_EAF,
                                    df_tl_ccsa, df_tl_ccsa_EAF, df_tl_ccsa_EAM, df_tl_ccsa_EA_EAF,
                                    df_tl_fada, df_tl_fada_EAF, df_tl_fada_EAM, df_tl_fada_EA_EAF
                                    ], sort=False, axis=1)
                if MGtoMGM and MGtoMGF:
                    df1 = pd.concat([timeFor_iter, 
                                    df_mix,
                                    df_w, df_b, df_wf, df_bf, df_wm, df_bm, 
                                    df_nt, df_nt_f, df_nt_m,
                                    df_tl_sup, df_tl_sup_EAF, df_tl_sup_EAM, df_tl_sup_EA_EAF,
                                    df_tl_unsup, df_tl_unsup_EAF, df_tl_unsup_EAM, df_tl_unsup_EA_EAF,
                                    df_tl_ccsa, df_tl_ccsa_EAF, df_tl_ccsa_EAM, df_tl_ccsa_EA_EAF,
                                    df_tl_fada, df_tl_fada_EAF, df_tl_fada_EAM, df_tl_fada_EA_EAF
                                    ], sort=False, axis=1)
            print (df1)
            res = res.append(df1)
        res.to_excel(out_file_name)

if __name__ == '__main__':
    main()
